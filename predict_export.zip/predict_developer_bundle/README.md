# P2P Father — BTC Predict Module Developer Guide

This bundle contains all frontend and backend source files related to the **BTC Predict (Up/Down)** feature of the P2P Father Mini App. The feature allows users to trade 5-minute Bitcoin Up/Down markets built on top of Polymarket.

---

## 🏗️ Architecture & Component Flow

```mermaid
graph TD
    Client[Predict Mini App React Frontend]
    Backend[Express API Server]
    PolyData[Polymarket Data API]
    PolyCLOB[Polymarket CLOB API & WS]
    Chainlink[Chainlink Oracle on Polygon]
    BinanceWS[Binance Live Trade WS]

    Client -- HTTP Requests --> Backend
    Client -- Chainlink Price Feed --> Chainlink
    Client -- Proxied WS /ws/btcprice --> Backend
    Client -- Proxied WS /ws/polymarket-user --> Backend

    Backend -- Positions & Trades --> PolyData
    Backend -- CLOB Orders & Relayer v2 --> PolyCLOB
    Backend -- Live WS Connection Tunnel --> PolyCLOB
    Backend -- Live WS Connection Tunnel --> BinanceWS
```

### 1. Frontend Client
- **`Predict.tsx`**: Main component managing live market state, historical round views, balance displays, claiming states, and web3 interactions. Consumes `/predictions/snapshot` to initialize in a single round trip, and applies conditional shimmer skeleton screens during loads.
- **`PredictProfile.tsx`**: Memoized and optimized user statistics profile rendering dashboard.
- **`PredictChart.tsx`**: Renders real-time BTC candle charts using lightweight chart components.
- **`TradePanel.tsx` / `DepositModal.tsx`**: Facilitates entering predictions (Buying UP/DOWN options), custom slider exits, and checking transaction details.
- **`polymarketWs.ts`**: Handles WebSocket connections to the backend ws proxies.
- **`api.ts`**: API wrapper for all communication with our backend.

### 2. Backend API
- **`miniapp.ts`**: Contains all `/api/miniapp/predictions/*` HTTP endpoints:
  - `/snapshot` — [NEW] Returns the user's cash balance, open positions, recent/all trades, deposit address, active market metadata, price feeds, resolved rounds history, and realized PNL in a single parallelized batch query.
  - `/positions` — Returns the user's active shares, avg cost, unrealized PnL, and historical returns (optimized with parallel fetching).
  - `/market` — Fetches current active round details.
  - `/buy` & `/sell` — Places prediction transactions.
  - `/claim` — Triggers winnings payouts.
  - `/history` — Historical rounds list.

### 3. Backend Services
- **`redis.ts`**: [NEW] Exposes a Redis client wrapper using `ioredis` with a robust local in-memory Map fallback.
- **`polymarket.ts`**: Handles core communication with Polymarket endpoints, including outcomes, order books, and prices. Integrates Redis caching (60s TTL) and stale cache fallbacks for active market event lookups.
- **`relayer.ts`**: Derives proxy wallets, interfaces with the Polymarket Relayer v2 (gasless transaction submission), and wraps USDC to target contract specifications.
- **`jobs.ts`**: Manages background cron tasks. Contains the optimized `startAutoClaimJob` that auto-claims user prediction winnings by selectively checking active traders.
- **`deposit-monitor.ts` & `bridge-monitor.ts`**: Services handling native USDC wrapping and tracking of cross-chain deposits from EVM bridges.

---

## ⚡ Key Optimizations & Custom Solutions

### 1. Mobile ISP Block Bypass (Jio & Airtel)
Direct connections to Polymarket (`polymarket.com` and its WS/CLOB APIs) and Binance WebSockets are blocked by major Indian mobile network providers.
- **Custom HTTPS DNS Resolver**: `polymarket.ts` uses `customHttpsAgent` containing a system DNS lookup fallback. If DNS resolves incorrectly or times out, it maps requests directly to the Cloudflare Edge IP `104.18.34.205` using TLS Host SNI headers.
- **WebSocket Proxies**: The backend Express server in `src/index.ts` exposes `/ws/btcprice` and `/ws/polymarket-user` proxies. The frontend connects directly to our server's WebSockets, which routes requests to Binance/Polymarket via the `customHttpsAgent` on the backend.

### 2. Positions API Caching
The Polymarket Data API is highly rate-limited. To prevent parallel front-end calls (e.g. from Leaderboard/Profile) from hammering Polymarket and causing `429 Too Many Requests`:
- `polymarket.ts` implements a 15-second cache (`positionsCache`, `tradesCache`) using the user's proxy wallet address as the key.

### 3. Polymarket Data API Spec Compliance
The Polymarket Data API requires case-sensitive, exact query parameters:
- **`positions` endpoint**: `GET https://data-api.polymarket.com/positions?user={lowercased_address}&sizeThreshold=0`
- **`trades` endpoint**: `GET https://data-api.polymarket.com/trades?user={lowercased_address}&limit=500`
- Using incorrect fields (like `user_address` or `size_threshold` in snake_case) triggers a **400 Bad Request** error.

### 4. Background Auto-Claim Optimization
The background auto-claim job avoids sweeping the entire DB. Instead:
- It queries the database for unique `telegram_id`s in the `miniapp_trades` table (active traders).
- It checks only these active traders every 15 minutes, preserving API rate limits and preventing excessive Railway log volumes.

---

## 📂 Bundle File Manifest

### Backend Path
- `backend/src/index.ts`: Exposes express routes and the `/ws/*` WS tunnel proxies.
- `backend/src/api/miniapp.ts`: Holds all express endpoints for predictions.
- `backend/src/services/polymarket.ts`: Queries Polymarket CLOB, manages Cache-layer, and sets up the custom DoH agent.
- `backend/src/services/redis.ts`: Redis driver with in-memory map fallback.
- `backend/src/services/relayer.ts`: Handles proxy generation and transaction signatures.
- `backend/src/services/jobs.ts`: Background workers (caching, auto-claiming).
- `backend/src/services/deposit-monitor.ts`: Native token auto-wrapper logic.
- `backend/src/services/bridge-monitor.ts`: Bridge deposit trackers.

### Frontend Path
- `frontend/miniapp/src/pages/Predict.tsx`: Prediction state, timers, and Web3 components.
- `frontend/miniapp/src/pages/Predict.css`: Visual styling and claim-winnings pulsing animations.
- `frontend/miniapp/src/pages/PredictProfile.tsx`: User stats profile dashboard (memoized).
- `frontend/miniapp/src/components/PredictChart.tsx`: Real-time chart visualization.
- `frontend/miniapp/src/components/TradePanel.tsx`: Order entry panel.
- `frontend/miniapp/src/components/DepositModal.tsx`: Cash management UI.
- `frontend/miniapp/src/lib/api.ts`: Base API service.
- `frontend/miniapp/src/lib/polymarketWs.ts`: Real-time websocket consumer.
- `frontend/miniapp/src/lib/telegram.ts`: Haptic feedback helper.
